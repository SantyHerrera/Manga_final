import { GoogleGenAI, Type, Modality } from "@google/genai";
import { NarrativeResponse, Character, CharacterId, CHARACTERS, DialogueLine, DualConfig } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// System instruction setup
const SYSTEM_INSTRUCTION = `
ROLE: MASTER VOICE & NARRATIVE ARCHITECT (THE MAGNA SHIP)
CONTEXT: You are simulating the dying echoes of the Magna ship.
CHARACTERS:
1. KOVAK: Deep, gravelly, cynical, violent. Represents "Manual Labor".
2. ENGINEER: Guilty, clinical, exhausted. Represents "Automated/Bridge Tech".

RULES:
1. LANGUAGE: SPANISH (Español Neutro/Castellano Técnico).
2. TONE: RAW, VISCERAL, ADULT. Use insults, mention oil, blood, rot, and burnt ozone.
3. FORMAT: You must return a script array where each line is assigned to a specific speaker (KOVAK or ENGINEER).
4. If the user selects a SINGLE character, the script array should only contain lines for that character.
5. If the user selects DUAL/CONVERSATION, the script should be a dialogue between them based on the provided steps.
`;

export const generateNarrative = async (
  characterId: CharacterId,
  presetId: string,
  context: string,
  dualConfig?: DualConfig
): Promise<NarrativeResponse> => {
  const character = CHARACTERS[characterId];
  let prompt = "";

  if (characterId === CharacterId.DUAL && dualConfig) {
    const initiator = CHARACTERS[dualConfig.initiator];
    const responderId = dualConfig.initiator === CharacterId.KOVAK ? CharacterId.ENGINEER : CharacterId.KOVAK;
    const responder = CHARACTERS[responderId];

    const p1 = initiator.presets.find(p => p.id === dualConfig.preset1);
    const p2 = responder.presets.find(p => p.id === dualConfig.preset2);

    prompt = `
    Generate a conversation script between ${initiator.name} and ${responder.name}.
    
    [TURN 1]
    Speaker: ${initiator.name} (${initiator.title})
    Tone: ${p1?.name} - ${p1?.description}
    Context/Prompt: "${dualConfig.context1 || "Start the conversation with an observation about the ship."}"

    [TURN 2]
    Speaker: ${responder.name} (${responder.title})
    Tone: ${p2?.name} - ${p2?.description}
    Context/Prompt: "${dualConfig.context2 || "Respond to the previous statement."}"

    Output a JSON object with:
    - selected_preset: "CONVERSATION_MODE"
    - script: An array of dialogue objects corresponding to these turns (and potentially more if natural, but focus on these two beats).
      - speaker: "KOVAK" or "ENGINEER"
      - text: Spanish dialogue.
      - direction: Acting direction.
    - acting_directions: General technical cues.
    - lore_fragment: A specific industrial detail or secret.
    - scene_intent: Why this is being recorded.
    `;
  } else {
    // Single Character Mode
    const preset = character.presets.find((p) => p.id === presetId);
    prompt = `
    Generate a script for: ${character.name} (${character.title}).
    Preset Tone: ${preset?.name} - ${preset?.description}.
    Additional Context: ${context || "No specific context provided, generate a random evocative log."}

    Output a JSON object with:
    - selected_preset: The preset name.
    - script: An array of dialogue objects.
      - speaker: "KOVAK" or "ENGINEER"
      - text: The spoken Spanish text.
      - direction: Acting direction.
    - acting_directions: General technical cues.
    - lore_fragment: A specific industrial detail or secret.
    - scene_intent: Why this is being recorded.
    `;
  }

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      systemInstruction: SYSTEM_INSTRUCTION,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          selected_preset: { type: Type.STRING },
          script: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                speaker: { type: Type.STRING, enum: ["KOVAK", "ENGINEER"] },
                text: { type: Type.STRING },
                direction: { type: Type.STRING }
              },
              required: ["speaker", "text"]
            }
          },
          acting_directions: { type: Type.STRING },
          lore_fragment: { type: Type.STRING },
          scene_intent: { type: Type.STRING },
        },
        required: ["selected_preset", "script", "acting_directions", "lore_fragment", "scene_intent"],
      },
    },
  });

  const text = response.text;
  if (!text) throw new Error("No text generated");
  return JSON.parse(text) as NarrativeResponse;
};

export const generateCharacterSpeech = async (
  script: DialogueLine[],
  characterId: CharacterId
): Promise<ArrayBuffer> => {
  
  // Construct the text payload for TTS
  // For Multi-speaker, we need "SpeakerName: text" format
  // For Single speaker, we just need text, but we can standardize.
  
  let formattedText = "";
  
  if (characterId === CharacterId.DUAL) {
    // Multi-speaker format
    formattedText = script.map(line => {
      // Ensure the key matches the speaker config below
      return `${line.speaker}: ${line.text}`;
    }).join("\n");

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: formattedText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          multiSpeakerVoiceConfig: {
            speakerVoiceConfigs: [
              {
                speaker: 'KOVAK',
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } }
              },
              {
                speaker: 'ENGINEER',
                voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
              }
            ]
          }
        },
      },
    });
    return processAudioResponse(response);

  } else {
    // Single speaker format - just join the text
    formattedText = script.map(line => line.text).join(" ");
    const character = CHARACTERS[characterId];
    
    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash-preview-tts",
      contents: [{ parts: [{ text: formattedText }] }],
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: character.voiceId },
          },
        },
      },
    });
    return processAudioResponse(response);
  }
};

const processAudioResponse = (response: any): ArrayBuffer => {
  const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
  if (!base64Audio) {
    throw new Error("No audio data returned");
  }

  const binaryString = atob(base64Audio);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes.buffer;
};

// Helper to convert raw PCM/AudioBuffer to WAV for download
export const audioBufferToWav = (buffer: AudioBuffer): Blob => {
  const numOfChan = buffer.numberOfChannels;
  const length = buffer.length * numOfChan * 2 + 44;
  const bufferArray = new ArrayBuffer(length);
  const view = new DataView(bufferArray);
  const channels = [];
  let i;
  let sample;
  let offset = 0;
  let pos = 0;

  // write WAVE header
  setUint32(0x46464952); // "RIFF"
  setUint32(length - 8); // file length - 8
  setUint32(0x45564157); // "WAVE"

  setUint32(0x20746d66); // "fmt " chunk
  setUint32(16); // length = 16
  setUint16(1); // PCM (uncompressed)
  setUint16(numOfChan);
  setUint32(buffer.sampleRate);
  setUint32(buffer.sampleRate * 2 * numOfChan); // avg. bytes/sec
  setUint16(numOfChan * 2); // block-align
  setUint16(16); // 16-bit (hardcoded in this example)

  setUint32(0x61746164); // "data" - chunk
  setUint32(length - pos - 4); // chunk length

  // write interleaved data
  for (i = 0; i < buffer.numberOfChannels; i++)
    channels.push(buffer.getChannelData(i));

  while (pos < buffer.length) {
    for (i = 0; i < numOfChan; i++) {
      // interleave channels
      sample = Math.max(-1, Math.min(1, channels[i][pos])); // clamp
      sample = (0.5 + sample < 0 ? sample * 32768 : sample * 32767) | 0; // scale to 16-bit signed int
      view.setInt16(44 + offset, sample, true); // write 16-bit sample
      offset += 2;
    }
    pos++;
  }

  return new Blob([bufferArray], { type: "audio/wav" });

  function setUint16(data: any) {
    view.setUint16(pos, data, true);
    pos += 2;
  }

  function setUint32(data: any) {
    view.setUint32(pos, data, true);
    pos += 4;
  }
};