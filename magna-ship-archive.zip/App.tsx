import React, { useState, useEffect } from 'react';
import { ConsoleHeader } from './components/ConsoleHeader';
import { CharacterSelector } from './components/CharacterSelector';
import { NarrativeDisplay } from './components/NarrativeDisplay';
import { CharacterId, CHARACTERS, NarrativeResponse, DualConfig } from './types';
import { generateNarrative, generateCharacterSpeech } from './services/geminiService';

const INITIAL_MESSAGE = "SISTEMAS ONLINE, INGENIERO. LAS VOCES DE LA MAGNA ESTÁN LISTAS. ¿CUÁL ES NUESTRO PRIMER REGISTRO?";

export default function App() {
  const [selectedCharId, setSelectedCharId] = useState<CharacterId>(CharacterId.KOVAK);
  const [selectedPreset, setSelectedPreset] = useState<string>(CHARACTERS[CharacterId.KOVAK].presets[0].id);
  const [contextInput, setContextInput] = useState<string>("");
  
  // Dual Mode State
  const [dualConfig, setDualConfig] = useState<DualConfig>({
    initiator: CharacterId.KOVAK,
    preset1: CHARACTERS[CharacterId.KOVAK].presets[0].id,
    context1: "",
    preset2: CHARACTERS[CharacterId.ENGINEER].presets[0].id,
    context2: ""
  });
  
  const [loading, setLoading] = useState(false);
  const [narrativeData, setNarrativeData] = useState<NarrativeResponse | null>(null);
  const [audioBuffer, setAudioBuffer] = useState<ArrayBuffer | null>(null);
  const [systemReady, setSystemReady] = useState(false);

  // Update preset when character changes to avoid invalid combinations
  const handleCharChange = (id: CharacterId) => {
    setSelectedCharId(id);
    if (id !== CharacterId.DUAL) {
      setSelectedPreset(CHARACTERS[id].presets[0].id);
    }
  };

  const handleGenerate = async () => {
    setLoading(true);
    setNarrativeData(null);
    setAudioBuffer(null);

    try {
      // 1. Generate Text Script
      const data = await generateNarrative(selectedCharId, selectedPreset, contextInput, dualConfig);
      setNarrativeData(data);

      // 2. Generate Audio based on the script structure
      const audio = await generateCharacterSpeech(data.script, selectedCharId);
      setAudioBuffer(audio);
      
    } catch (error) {
      console.error("Transmission Error:", error);
      alert("ERROR: CONNECTION TO MAGNA CORE INTERRUPTED. CHECK API CONFIG.");
    } finally {
      setLoading(false);
    }
  };

  // Intro Effect
  useEffect(() => {
    const timer = setTimeout(() => setSystemReady(true), 1000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen p-4 md:p-8 lg:p-12 max-w-7xl mx-auto selection:bg-red-900 selection:text-white pb-32">
      
      {!systemReady ? (
        <div className="h-[80vh] flex items-center justify-center">
           <div className="text-orange-600 font-mono text-xl animate-pulse">INITIALIZING CORE...</div>
        </div>
      ) : (
        <>
          <ConsoleHeader />
          
          <div className="border border-zinc-800 bg-zinc-900/20 p-6 mb-8">
             <p className="text-green-500/80 font-mono text-sm md:text-base animate-pulse">
                {">"} {INITIAL_MESSAGE}
             </p>
          </div>

          <CharacterSelector
            selectedChar={selectedCharId}
            onSelectChar={handleCharChange}
            selectedPreset={selectedPreset}
            onSelectPreset={setSelectedPreset}
            customContext={contextInput}
            onContextChange={setContextInput}
            dualConfig={dualConfig}
            onDualConfigChange={setDualConfig}
            onGenerate={handleGenerate}
            disabled={loading}
          />

          {loading && (
            <div className="mt-12 text-center space-y-4">
              <div className="inline-block w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
              <p className="text-zinc-500 text-xs tracking-[0.2em] uppercase">Simulating Neural Echoes...</p>
            </div>
          )}

          {narrativeData && (
            <NarrativeDisplay
              data={narrativeData}
              character={CHARACTERS[selectedCharId]}
              audioBuffer={audioBuffer}
            />
          )}
        </>
      )}
    </div>
  );
}