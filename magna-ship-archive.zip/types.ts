export enum CharacterId {
  KOVAK = 'KOVAK',
  ENGINEER = 'ENGINEER',
  DUAL = 'DUAL'
}

export interface Preset {
  id: string;
  name: string;
  description: string;
}

export interface Character {
  id: CharacterId;
  name: string;
  title: string;
  description: string;
  voiceId: string; // Primary voice, or ignored if Dual
  themeColor: string;
  presets: Preset[];
}

export interface DialogueLine {
  speaker: CharacterId; // Who is speaking this specific line
  text: string;
  direction?: string; // Specific acting direction for this line
}

export interface DualConfig {
  initiator: CharacterId; // KOVAK or ENGINEER
  preset1: string;
  context1: string;
  preset2: string;
  context2: string;
}

// JSON Schema response from Gemini Text Model
export interface NarrativeResponse {
  selected_preset: string;
  script: DialogueLine[]; // Array of lines instead of single block
  acting_directions: string; // General scene directions
  lore_fragment: string;
  scene_intent: string;
}

export const CHARACTERS: Record<CharacterId, Character> = {
  [CharacterId.KOVAK]: {
    id: CharacterId.KOVAK,
    name: "Kovak Varkas",
    title: "The Ghost of the Forge",
    description: "Cynical, traditionalist, violent. Represents Manual Labor. Deep, gravelly voice.",
    voiceId: "Fenrir",
    themeColor: "text-orange-600 border-orange-600 bg-orange-950/20",
    presets: [
      { id: "HYDRAULIC_RAGE", name: "HYDRAULIC RAGE", description: "Pure fury, screaming over machine noise." },
      { id: "OILY_MELANCHOLY", name: "OILY MELANCHOLY", description: "Breaking voice, heavy sadness." },
      { id: "TRENCH_SARCASM", name: "TRENCH SARCASM", description: "Mocking tone, dry wheezing laugh." },
      { id: "THE_SENTENCE", name: "THE SENTENCE", description: "Cold, terrifyingly calm whisper." }
    ]
  },
  [CharacterId.ENGINEER]: {
    id: CharacterId.ENGINEER,
    name: "The Engineer",
    title: "Protagonist / Bridge Tech",
    description: "Guilty, sleep-deprived, clinical. Represents Automated Tech. Integrated life-support.",
    voiceId: "Zephyr",
    themeColor: "text-cyan-500 border-cyan-500 bg-cyan-950/20",
    presets: [
      { id: "NEGACION_CLINICA", name: "NEGACIÓN CLÍNICA", description: "Fast, monotone, hiding fear." },
      { id: "PARANOIA_SUSURRADA", name: "PARANOIA SUSURRADA", description: "Shaky whisper, near breakdown." },
      { id: "MANDO_QUEBRADO", name: "MANDO QUEBRADO", description: "Failed authoritative tone, cracking." },
      { id: "EXTENUACION", name: "EXTENUACIÓN", description: "Dragged voice, heavy exhales." }
    ]
  },
  [CharacterId.DUAL]: {
    id: CharacterId.DUAL,
    name: "Conversation Mode",
    title: "Ghost in the Machine",
    description: "Simultaneous transmission. Configure a dialogue between two entities.",
    voiceId: "MIXED", // Special flag
    themeColor: "text-purple-500 border-purple-600 bg-purple-950/20",
    presets: [] // Not used in Dual Config mode directly
  }
};