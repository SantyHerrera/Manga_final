import React from 'react';
import { Character, CharacterId, CHARACTERS, DualConfig } from '../types';

interface CharacterSelectorProps {
  selectedChar: CharacterId;
  onSelectChar: (id: CharacterId) => void;
  selectedPreset: string;
  onSelectPreset: (id: string) => void;
  customContext: string;
  onContextChange: (val: string) => void;
  dualConfig: DualConfig;
  onDualConfigChange: (config: DualConfig) => void;
  disabled: boolean;
  onGenerate: () => void;
}

export const CharacterSelector: React.FC<CharacterSelectorProps> = ({
  selectedChar,
  onSelectChar,
  selectedPreset,
  onSelectPreset,
  customContext,
  onContextChange,
  dualConfig,
  onDualConfigChange,
  disabled,
  onGenerate
}) => {
  const character = CHARACTERS[selectedChar];
  const isDual = selectedChar === CharacterId.DUAL;

  // Helper to update dual config part
  const updateDual = (field: keyof DualConfig, value: any) => {
    onDualConfigChange({ ...dualConfig, [field]: value });
  };

  const handleSwapRoles = () => {
    onDualConfigChange({
      ...dualConfig,
      initiator: dualConfig.initiator === CharacterId.KOVAK ? CharacterId.ENGINEER : CharacterId.KOVAK,
      // Optional: Swap contents too? Probably better to keep contents in place but swap the "role" of the slot
      // Or just swap the Initiator ID, which changes the available presets for that slot.
      // Let's reset presets to defaults of new characters to avoid invalid IDs.
      preset1: CHARACTERS[dualConfig.initiator === CharacterId.KOVAK ? CharacterId.ENGINEER : CharacterId.KOVAK].presets[0].id,
      preset2: CHARACTERS[dualConfig.initiator === CharacterId.KOVAK ? CharacterId.KOVAK : CharacterId.ENGINEER].presets[0].id
    });
  };

  const initiatorChar = CHARACTERS[dualConfig.initiator];
  const responderChar = CHARACTERS[dualConfig.initiator === CharacterId.KOVAK ? CharacterId.ENGINEER : CharacterId.KOVAK];

  return (
    <div className="mb-8 space-y-8">
      
      {/* 1. Character Mode Selection */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
        {(Object.keys(CHARACTERS) as CharacterId[]).map((id) => {
          const char = CHARACTERS[id];
          const isActive = selectedChar === id;
          
          let activeClass = '';
          if (id === CharacterId.KOVAK) activeClass = 'border-orange-600 bg-orange-900/10 text-orange-500';
          else if (id === CharacterId.ENGINEER) activeClass = 'border-cyan-600 bg-cyan-900/10 text-cyan-500';
          else activeClass = 'border-purple-600 bg-purple-900/10 text-purple-500'; 
          
          return (
            <button
              key={id}
              onClick={() => onSelectChar(id)}
              disabled={disabled}
              className={`p-3 md:p-4 border transition-all duration-300 text-left md:text-center ${
                isActive ? activeClass : 'border-zinc-800 text-zinc-600 hover:border-zinc-700 hover:text-zinc-400'
              }`}
            >
              <div className="font-bold text-base md:text-lg">{char.name}</div>
              <div className="text-[10px] uppercase opacity-70 mt-1 truncate">{char.title}</div>
            </button>
          );
        })}
      </div>

      {/* 2. Configuration Area */}
      {!isDual ? (
        // --- SINGLE CHARACTER MODE ---
        <div className={`grid grid-cols-1 lg:grid-cols-2 gap-8 p-6 border ${
             selectedChar === CharacterId.KOVAK ? 'border-orange-900/30 bg-orange-950/5' : 'border-cyan-900/30 bg-cyan-950/5'
        }`}>
          {/* Preset */}
          <div>
            <h2 className="text-xs uppercase tracking-widest text-zinc-500 font-bold mb-2">Vocal Preset</h2>
            <select
              value={selectedPreset}
              onChange={(e) => onSelectPreset(e.target.value)}
              disabled={disabled}
              className="w-full bg-black border border-zinc-700 text-zinc-300 p-3 focus:outline-none focus:border-white transition-colors uppercase text-sm"
            >
              {character.presets.map((p) => (
                <option key={p.id} value={p.id}>{p.name}</option>
              ))}
            </select>
            <div className="mt-2 text-xs text-zinc-500 min-h-[1.5em]">
              {character.presets.find(p => p.id === selectedPreset)?.description}
            </div>
          </div>
          {/* Context */}
          <div>
            <h2 className="text-xs uppercase tracking-widest text-zinc-500 font-bold mb-2">Narrative Context</h2>
            <textarea
              value={customContext}
              onChange={(e) => onContextChange(e.target.value)}
              placeholder="Describe the situation..."
              disabled={disabled}
              rows={4}
              className="w-full bg-zinc-900/50 border border-zinc-700 text-zinc-300 p-3 focus:outline-none focus:border-zinc-500 transition-colors placeholder-zinc-700 text-sm resize-none"
            />
          </div>
        </div>
      ) : (
        // --- DUAL / CONVERSATION MODE ---
        <div className="border border-purple-900/30 bg-purple-950/5 p-6 space-y-6 relative">
          
          <div className="absolute top-4 right-4 z-10">
            <button 
               onClick={handleSwapRoles}
               disabled={disabled}
               className="text-xs flex items-center gap-2 bg-zinc-900 border border-zinc-700 hover:border-zinc-500 px-3 py-1 text-zinc-400 hover:text-white transition-all uppercase tracking-widest"
            >
              Swap Roles <span>⇄</span>
            </button>
          </div>

          <h2 className="text-xs uppercase tracking-widest text-purple-500 font-bold border-b border-purple-900/30 pb-2">
            Conversation Sequence Config
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            
            {/* PART 1: INITIATOR */}
            <div className="space-y-4">
              <div className={`flex items-center gap-2 text-sm font-bold uppercase ${initiatorChar.id === CharacterId.KOVAK ? 'text-orange-500' : 'text-cyan-500'}`}>
                <span>Part 1: The Message ({initiatorChar.name})</span>
              </div>
              
              <select
                value={dualConfig.preset1}
                onChange={(e) => updateDual('preset1', e.target.value)}
                disabled={disabled}
                className="w-full bg-black border border-zinc-700 text-zinc-300 p-2 text-xs focus:outline-none focus:border-zinc-500 uppercase"
              >
                {initiatorChar.presets.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} - {p.description.substring(0,30)}...</option>
                ))}
              </select>

              <textarea
                value={dualConfig.context1}
                onChange={(e) => updateDual('context1', e.target.value)}
                placeholder={`What does ${initiatorChar.name.split(' ')[0]} say?`}
                disabled={disabled}
                rows={3}
                className={`w-full bg-zinc-900/50 border-l-2 text-zinc-300 p-3 focus:outline-none transition-colors placeholder-zinc-700 text-sm resize-none ${
                   initiatorChar.id === CharacterId.KOVAK ? 'border-orange-900 focus:border-orange-600' : 'border-cyan-900 focus:border-cyan-600'
                }`}
              />
            </div>

            {/* PART 2: RESPONDER */}
            <div className="space-y-4">
               <div className={`flex items-center gap-2 text-sm font-bold uppercase ${responderChar.id === CharacterId.KOVAK ? 'text-orange-500' : 'text-cyan-500'}`}>
                <span>Part 2: The Response ({responderChar.name})</span>
              </div>
              
              <select
                value={dualConfig.preset2}
                onChange={(e) => updateDual('preset2', e.target.value)}
                disabled={disabled}
                className="w-full bg-black border border-zinc-700 text-zinc-300 p-2 text-xs focus:outline-none focus:border-zinc-500 uppercase"
              >
                {responderChar.presets.map((p) => (
                  <option key={p.id} value={p.id}>{p.name} - {p.description.substring(0,30)}...</option>
                ))}
              </select>

              <textarea
                value={dualConfig.context2}
                onChange={(e) => updateDual('context2', e.target.value)}
                placeholder={`How does ${responderChar.name.split(' ')[0]} respond?`}
                disabled={disabled}
                rows={3}
                className={`w-full bg-zinc-900/50 border-l-2 text-zinc-300 p-3 focus:outline-none transition-colors placeholder-zinc-700 text-sm resize-none ${
                   responderChar.id === CharacterId.KOVAK ? 'border-orange-900 focus:border-orange-600' : 'border-cyan-900 focus:border-cyan-600'
                }`}
              />
            </div>
          </div>
        </div>
      )}

      {/* Generate Button */}
      <button
        onClick={onGenerate}
        disabled={disabled}
        className={`w-full py-4 font-bold tracking-widest uppercase transition-all duration-200 mt-4 ${
          disabled 
            ? 'bg-zinc-800 text-zinc-600 cursor-not-allowed'
            : selectedChar === CharacterId.KOVAK 
              ? 'bg-orange-700 hover:bg-orange-600 text-black' 
              : selectedChar === CharacterId.ENGINEER
                ? 'bg-cyan-700 hover:bg-cyan-600 text-black'
                : 'bg-purple-700 hover:bg-purple-600 text-black'
        }`}
      >
        {disabled ? 'Processing Transmission...' : isDual ? 'Simulate Conversation' : 'Simulate Log'}
      </button>

    </div>
  );
};