import React, { useEffect, useRef, useState } from 'react';
import { NarrativeResponse, Character, CharacterId } from '../types';
import { audioBufferToWav } from '../services/geminiService';

interface NarrativeDisplayProps {
  data: NarrativeResponse;
  character: Character;
  audioBuffer: ArrayBuffer | null;
}

export const NarrativeDisplay: React.FC<NarrativeDisplayProps> = ({ data, character, audioBuffer }) => {
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  
  const accentColor = character.id === CharacterId.KOVAK ? 'text-orange-500' : 
                      character.id === CharacterId.ENGINEER ? 'text-cyan-500' : 'text-purple-500';
  
  const borderColor = character.id === CharacterId.KOVAK ? 'border-orange-500' : 
                      character.id === CharacterId.ENGINEER ? 'border-cyan-500' : 'border-purple-500';

  useEffect(() => {
    if (!audioBuffer) return;

    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    ctx.decodeAudioData(audioBuffer.slice(0)).then((decoded) => {
      const wavBlob = audioBufferToWav(decoded);
      const url = URL.createObjectURL(wavBlob);
      setAudioUrl(url);
    });

    return () => {
      if (audioUrl) URL.revokeObjectURL(audioUrl);
    };
  }, [audioBuffer]);


  return (
    <div className={`relative mt-12 p-6 border ${borderColor} bg-black/50 animate-in fade-in slide-in-from-bottom-4 duration-700`}>
      {/* Decorative Corner */}
      <div className={`absolute -top-1 -right-1 w-4 h-4 border-t border-r ${borderColor}`}></div>
      <div className={`absolute -bottom-1 -left-1 w-4 h-4 border-b border-l ${borderColor}`}></div>

      {/* Metadata Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 border-b border-zinc-800 pb-4 gap-4">
        <div>
          <span className={`text-xs font-bold ${accentColor} uppercase tracking-widest mr-4`}>
             /// {data.selected_preset}
          </span>
          <span className="text-zinc-500 text-xs">LOG_ID: {Math.random().toString(36).substr(2, 9).toUpperCase()}</span>
        </div>
        <div className="text-right">
           <span className="text-zinc-600 text-xs uppercase block">Scene Intent</span>
           <span className="text-zinc-300 text-sm">{data.scene_intent}</span>
        </div>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        
        {/* Script Section */}
        <div className="lg:col-span-2 space-y-8">
          <div className="space-y-2">
             <h3 className="text-zinc-500 text-xs uppercase tracking-widest">Global Directions</h3>
             <p className="text-zinc-400 italic text-sm font-light">
               {data.acting_directions}
             </p>
          </div>

          <div className="space-y-4">
            <h3 className="text-zinc-500 text-xs uppercase tracking-widest">Audio Transcript</h3>
            <div className="space-y-4 font-mono">
              {data.script.map((line, idx) => (
                <div key={idx} className="flex flex-col space-y-1">
                  <div className="flex items-baseline space-x-2">
                    <span className={`text-xs font-bold uppercase tracking-wider ${
                      line.speaker === CharacterId.KOVAK ? 'text-orange-700' : 'text-cyan-700'
                    }`}>
                      {line.speaker} {">"}
                    </span>
                    {line.direction && (
                       <span className="text-zinc-600 text-xs italic">
                         {line.direction}
                       </span>
                    )}
                  </div>
                  <p className={`text-lg md:text-xl leading-relaxed font-medium pl-6 ${
                    line.speaker === CharacterId.KOVAK ? 'text-orange-500' : 'text-cyan-500'
                  }`}>
                    "{line.text}"
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Sidebar: Lore & Audio */}
        <div className="lg:col-span-1 space-y-8 border-l border-zinc-800 pl-0 lg:pl-8">
           
           {/* Lore Box */}
           <div className="bg-zinc-900/30 p-4 border border-zinc-800">
              <h3 className="text-zinc-500 text-xs uppercase tracking-widest mb-2">Lore Fragment</h3>
              <p className="text-zinc-400 text-xs leading-5">
                {data.lore_fragment}
              </p>
           </div>

           {/* Audio Player */}
           <div className="space-y-4">
              <h3 className="text-zinc-500 text-xs uppercase tracking-widest">Voice Synthesis</h3>
              
              {audioUrl ? (
                <div className="flex flex-col gap-3">
                  <audio 
                    ref={audioRef}
                    controls 
                    src={audioUrl} 
                    className="w-full h-8 opacity-70 hover:opacity-100 transition-opacity"
                  />
                  
                  <a 
                    href={audioUrl} 
                    download={`magna_log_${character.id}_${Date.now()}.wav`}
                    className={`text-center py-2 px-4 text-xs font-bold border ${borderColor} ${accentColor} hover:bg-zinc-900 uppercase transition-colors`}
                  >
                    Download Transmission
                  </a>
                </div>
              ) : (
                 <div className="h-12 w-full bg-zinc-900/50 animate-pulse flex items-center justify-center border border-zinc-800">
                    <span className="text-xs text-zinc-600">DECRYPTING AUDIO STREAM...</span>
                 </div>
              )}
           </div>
        </div>

      </div>
    </div>
  );
};