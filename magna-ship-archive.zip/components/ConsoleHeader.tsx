import React from 'react';

export const ConsoleHeader: React.FC = () => {
  return (
    <div className="border-b border-zinc-800 pb-6 mb-8">
      <h1 className="text-3xl font-bold tracking-widest text-zinc-100 uppercase mb-2">
        <span className="text-red-600 mr-2">///</span> 
        Magna Ship Archive 
        <span className="text-zinc-600 text-sm ml-4 font-normal normal-case tracking-normal">Sector Kovak // Node 404</span>
      </h1>
      <p className="text-zinc-500 text-sm max-w-2xl">
        WARNING: Neural Link Unstable. Accessing distinct personality fragments from the Core Data Bank. 
        Expect interference between <span className="text-orange-600">Manual Labor</span> and <span className="text-cyan-600">Bridge Command</span>.
      </p>
    </div>
  );
};